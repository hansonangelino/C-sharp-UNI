namespace BMI_App
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            bmiLbl.Text = string.Empty;
            detailLbl.Text = string.Empty;
            warningLbl.Text = string.Empty;
            pictureBox1.Image = Properties.Resources._0;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void calcuBtn_Click(object sender, EventArgs e)
        {
            try
            {
                // Parse height and weight inputs
                int height = int.Parse(heightInput.Text);
                int weight = int.Parse(weightInput.Text);

                // Convert height to meters
                double heightM = height / 100.0; // Ensure floating point division

                // Calculate BMI
                double bmi = Math.Round(weight / (heightM * heightM), 2);
                if (bmi < 18.5)
                {
                    detailLbl.Text = "Underweight";
                    pictureBox1.Image = Properties.Resources._1;
                }
                else if (bmi >= 18.5 & bmi <= 24.9)
                {
                    detailLbl.Text = "Normal";
                    pictureBox1.Image = Properties.Resources._2;
                }
                else if (bmi >= 25 & bmi <= 29.9)
                {
                    detailLbl.Text = "Overweight";
                    pictureBox1.Image = Properties.Resources._3;
                }
                else if (bmi >= 30 & bmi <= 34.9)
                {
                    detailLbl.Text = "Obesity (Class 1)";
                    pictureBox1.Image = Properties.Resources._4;
                }
                else if (bmi >= 35 & bmi <= 39.9)
                {
                    detailLbl.Text = "Obesity (Class 2)";
                    pictureBox1.Image = Properties.Resources._5;
                }
                else
                {
                    detailLbl.Text = "Obesity (Class 3)";
                    pictureBox1.Image = Properties.Resources._6;
                }
                bmiLbl.Text = bmi.ToString();
                warningLbl.ForeColor = Color.Green;
                warningLbl.Text = "BMI Calculated";
            }
            catch
            {
                warningLbl.ForeColor = Color.Firebrick;
                warningLbl.Text = "Please fill all the fields";
            }
        }

        private void clearBtn_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(weightInput.Text) | string.IsNullOrEmpty(heightInput.Text))
            {
                warningLbl.ForeColor = Color.Firebrick;
                warningLbl.Text = "Fields already empty";
            }
            else
            {
                heightInput.Text = string.Empty;
                weightInput.Text = string.Empty;
                detailLbl.Text = string.Empty;
                bmiLbl.Text = string.Empty;
                warningLbl.ForeColor = Color.Green;
                warningLbl.Text = "Fields cleared";
                pictureBox1.Image = Properties.Resources._0;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}