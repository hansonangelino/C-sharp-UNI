﻿namespace BMI_App
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            titleLbl = new Label();
            label2 = new Label();
            label3 = new Label();
            detailLbl = new Label();
            bmiLbl = new Label();
            heightInput = new TextBox();
            weightInput = new TextBox();
            calcuBtn = new Button();
            clearBtn = new Button();
            warningLbl = new Label();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // titleLbl
            // 
            titleLbl.Font = new Font("Microsoft JhengHei UI", 20F, FontStyle.Bold, GraphicsUnit.Point);
            titleLbl.Location = new Point(0, 9);
            titleLbl.Name = "titleLbl";
            titleLbl.Size = new Size(1018, 98);
            titleLbl.TabIndex = 0;
            titleLbl.Text = "BMI CALCULATOR APP";
            titleLbl.TextAlign = ContentAlignment.MiddleCenter;
            titleLbl.Click += label1_Click;
            // 
            // label2
            // 
            label2.Font = new Font("Microsoft JhengHei UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(359, 188);
            label2.Name = "label2";
            label2.Size = new Size(134, 46);
            label2.TabIndex = 1;
            label2.Text = "Weight (kg)";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.Font = new Font("Microsoft JhengHei UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(359, 142);
            label3.Name = "label3";
            label3.Size = new Size(131, 46);
            label3.TabIndex = 2;
            label3.Text = "Height (cm)";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            label3.Click += label3_Click;
            // 
            // detailLbl
            // 
            detailLbl.BackColor = Color.Transparent;
            detailLbl.Font = new Font("Microsoft JhengHei UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            detailLbl.ImageAlign = ContentAlignment.MiddleLeft;
            detailLbl.Location = new Point(499, 325);
            detailLbl.Name = "detailLbl";
            detailLbl.Size = new Size(247, 24);
            detailLbl.TabIndex = 3;
            detailLbl.Text = "(detail)";
            detailLbl.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // bmiLbl
            // 
            bmiLbl.Anchor = AnchorStyles.Left;
            bmiLbl.BackColor = Color.Transparent;
            bmiLbl.Font = new Font("Microsoft JhengHei UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            bmiLbl.ImageAlign = ContentAlignment.MiddleLeft;
            bmiLbl.Location = new Point(359, 325);
            bmiLbl.Name = "bmiLbl";
            bmiLbl.Size = new Size(131, 24);
            bmiLbl.TabIndex = 4;
            bmiLbl.Text = "(bmi)";
            bmiLbl.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // heightInput
            // 
            heightInput.Font = new Font("Microsoft JhengHei UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            heightInput.Location = new Point(499, 150);
            heightInput.Name = "heightInput";
            heightInput.Size = new Size(154, 31);
            heightInput.TabIndex = 5;
            // 
            // weightInput
            // 
            weightInput.Font = new Font("Microsoft JhengHei UI", 14F, FontStyle.Regular, GraphicsUnit.Point);
            weightInput.Location = new Point(499, 196);
            weightInput.Name = "weightInput";
            weightInput.Size = new Size(154, 31);
            weightInput.TabIndex = 6;
            // 
            // calcuBtn
            // 
            calcuBtn.BackColor = Color.Green;
            calcuBtn.Font = new Font("Microsoft JhengHei UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            calcuBtn.ForeColor = SystemColors.ButtonHighlight;
            calcuBtn.Location = new Point(499, 282);
            calcuBtn.Name = "calcuBtn";
            calcuBtn.Size = new Size(154, 37);
            calcuBtn.TabIndex = 7;
            calcuBtn.Text = "Calculate";
            calcuBtn.UseVisualStyleBackColor = false;
            calcuBtn.Click += calcuBtn_Click;
            // 
            // clearBtn
            // 
            clearBtn.BackColor = Color.Firebrick;
            clearBtn.Font = new Font("Microsoft JhengHei UI Light", 12F, FontStyle.Regular, GraphicsUnit.Point);
            clearBtn.ForeColor = SystemColors.ButtonHighlight;
            clearBtn.Location = new Point(359, 282);
            clearBtn.Name = "clearBtn";
            clearBtn.Size = new Size(131, 37);
            clearBtn.TabIndex = 8;
            clearBtn.Text = "Clear";
            clearBtn.UseVisualStyleBackColor = false;
            clearBtn.Click += clearBtn_Click;
            // 
            // warningLbl
            // 
            warningLbl.AutoSize = true;
            warningLbl.Font = new Font("Microsoft JhengHei UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            warningLbl.ForeColor = Color.Firebrick;
            warningLbl.Location = new Point(499, 242);
            warningLbl.Name = "warningLbl";
            warningLbl.Size = new Size(74, 18);
            warningLbl.TabIndex = 9;
            warningLbl.Text = "(warning)";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(454, 563);
            label1.Name = "label1";
            label1.Size = new Size(117, 15);
            label1.TabIndex = 10;
            label1.Text = "丘漢森 - 411101164";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources._0;
            pictureBox1.Location = new Point(280, 361);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(466, 191);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 11;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1018, 596);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Controls.Add(warningLbl);
            Controls.Add(clearBtn);
            Controls.Add(calcuBtn);
            Controls.Add(weightInput);
            Controls.Add(heightInput);
            Controls.Add(bmiLbl);
            Controls.Add(detailLbl);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(titleLbl);
            Name = "Form1";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label titleLbl;
        private Label label2;
        private Label label3;
        private Label detailLbl;
        private Label bmiLbl;
        private TextBox heightInput;
        private TextBox weightInput;
        private Button calcuBtn;
        private Button clearBtn;
        private Label warningLbl;
        private Label label1;
        private PictureBox pictureBox1;
    }
}